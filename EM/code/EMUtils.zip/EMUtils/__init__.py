
' utils functions for paper work '
__author__ = "Yeeef"






